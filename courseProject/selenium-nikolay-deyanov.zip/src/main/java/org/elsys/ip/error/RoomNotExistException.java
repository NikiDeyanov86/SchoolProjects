package org.elsys.ip.error;

public class RoomNotExistException extends Exception {
    public RoomNotExistException(String message) {
        super(message);
    }
}
