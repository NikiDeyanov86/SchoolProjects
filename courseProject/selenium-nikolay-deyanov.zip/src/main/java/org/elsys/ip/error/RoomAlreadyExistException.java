package org.elsys.ip.error;

public class RoomAlreadyExistException extends Exception {
    public RoomAlreadyExistException(String message) {
        super(message);
    }
}
